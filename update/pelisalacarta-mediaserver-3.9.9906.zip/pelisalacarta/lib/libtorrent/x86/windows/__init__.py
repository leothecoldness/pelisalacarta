# -*- coding: iso-8859-1 -*-
#------------------------------------------------------------
# pelisalacarta
# librerias libtorrent para Windows x86
# http://blog.tvalacarta.info/plugin-xbmc/pelisalacarta/
#------------------------------------------------------------
from libtorrent import *
